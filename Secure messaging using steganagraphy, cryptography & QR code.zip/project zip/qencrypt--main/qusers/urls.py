from django.urls import path
from .views import User_login, extract_QR, User_Logout
urlpatterns = [
    path("login/", User_login, name="userlogin"),
    path("extractmessage/", extract_QR, name="extractmessage"),
    path("ulogout/", User_Logout, name="ulogout"),
]
