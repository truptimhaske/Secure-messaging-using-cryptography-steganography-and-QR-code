from django.dispatch import receiver
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from qradmin.helper_functions import crypt
from django.contrib.auth.decorators import login_required
from qradmin.models import SecureMessage
import cv2
from django.conf import settings
import json
# Create your views here.

def User_login(request):
    if request.method == "POST":
        user = authenticate(username=request.POST.get("uname"), password=request.POST.get("pswd"))
        if user is not None:
            login(request, user)
            return redirect("extractmessage")    
        else:
            error = "Invalid Credentials"
            return render(request, "User_Login.html", {"error_msg":error})        
    return render(request,"User_Login.html")

@login_required
def extract_QR(request):
    context = SecureMessage.objects.filter(receiver_mail=request.user.email).values('receiver_mail','timestamp')[0:3]
    if request.method == "POST":
        if 'qr_file'  in request.FILES:
            file = request.FILES.get('qr_file')
            print("file-----------",file)
            print(file.name)
            with open("extracted_qr.png","wb") as f:
                f.write(file.read())
            f.close()
            img = cv2.imread("extracted_qr.png")
            det=cv2.QRCodeDetector()
            val, pts, st_code=det.detectAndDecode(img)
            # print(request.user)
            qr_message_ = val.split(",")
            original_message = decrypt_message(request.user,qr_message_[0],qr_message_[1])
            
            if original_message == "No":
                context_ = {"message":"You do not have permission to deciphere this message.","message_class":"alert-danger"}
                return render(request,"User_1.html",context_)
            # return HttpResponse(original_message)
            return render(request,"User_2.html",{"original_message":original_message, "context":context})

    return render(request,"User_1.html", {"context":context})


def User_Logout(request):
    logout(request)
    return redirect("userlogin")

def decrypt_message(user_email,m_id,message):
    try:
        item = SecureMessage.objects.filter(message_id=m_id).values()[0]
        if str(user_email.email) == item.get("receiver_mail"):
            publickey_ = int(item.get("publicKey"))
            modulus = int(item.get('modulus'))
            totient = int(item.get('phi'))
            cipherText_ = int(item.get('encrypted_message'))
            bits = 52
            print(int(message) == cipherText_)
            if int(message) == cipherText_:
                privateKey = crypt.generatePrivateKey(publickey_, totient)
                jsonDec = json.decoder.JSONDecoder()
                ct_list = jsonDec.decode(item.get("ctlist"))

                deciphered_text = crypt.decrypt(ct_list, cipherText_, privateKey, modulus)
                print(deciphered_text)
                return deciphered_text
        return "No"
    except Exception as e:
        return f"Something went wrong {e}"