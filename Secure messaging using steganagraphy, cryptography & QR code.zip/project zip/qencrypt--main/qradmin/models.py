from django.db import models

# Create your models here.

class SecureMessage(models.Model):
    message_id = models.AutoField(primary_key=True)
    ctlist = models.TextField(blank=True, null=True)
    publicKey = models.TextField(blank=True, null=True)
    phi = models.TextField(blank=True, null=True)
    encrypted_message = models.CharField(max_length=500,default=True, blank=True)
    modulus = models.TextField(blank=True, null=True)
    receiver_mail = models.EmailField(default=True, blank=True)
    timestamp = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.message_id}"
