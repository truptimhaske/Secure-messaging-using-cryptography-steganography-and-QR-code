from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
import qrcode
import qrcode.image.svg
from io import BytesIO
from qradmin.helper_functions.send__mail import send_qenc_cred, send_qr_mail
from qradmin.helper_functions import crypt
from django.contrib.auth.decorators import login_required
from django.conf import settings
from qradmin.models import SecureMessage
from django.contrib.auth.hashers import make_password
import secrets
import json
import os

# Create your views here.

def Admin_login(request):
    if request.method == "POST":
        user = authenticate(username=request.POST.get("uname"), password=request.POST.get("pswd"))
        print("login authentication user", user, request.POST.get("uname"), request.POST.get("pswd"))
        if user is not None:
            print("authenticated user............")
            if user.is_superuser:
                login(request, user)    
                return redirect("generateqr")
            else:
                error = "You do not have permission to admin."
                return render(request, "Admin_Login.html", {"error_msg":error})            
        else:
            error = "Invalid Credentials"
            return render(request, "Admin_Login.html", {"error_msg":error})        
    return render(request, "Admin_Login.html")

def common_Logout(request):
    logout(request)
    return redirect("adminlogin")

@login_required
def generate_QR(request):
    context = {}
    context = {"context":SecureMessage.objects.filter().values('receiver_mail','timestamp')[0:3]}
    if request.method == "POST" and "send_invite"  in request.POST:
        email = request.POST.get("send_mail")
        password = secrets.token_urlsafe(8)
        print(User.objects.filter(email=email,username=email).values().exists())
        if not User.objects.filter(email=email).exists():
            user_created = User.objects.create(username=email, password=make_password(password), email=email)
            message = send_qenc_cred(email,password)
            context = {"message":f"Invitation successfully sent to {email} successfully.","message_class":"alert-success"}
            return render(request, "Admin_1.html", context=context)    
        else:
            context = {"message":"User already exists please try with another email..","message_class":"alert-danger"}
            return render(request, "Admin_1.html", context=context)    
        
    if request.method == "POST":
        message = request.POST.get("message")
        email = request.POST.get("email")
        if User.objects.filter(email=email).values().exists():
            #Securing the message to generate qr code
            n, phi, private_key, public_key = crypt.runRSA(52)
            ct_list, ciphertext = crypt.encrypt(message, public_key, n)
            deciphered_text = crypt.decrypt(ct_list, ciphertext, private_key, n)
            sec_message = SecureMessage.objects.create(
            modulus = n,
            encrypted_message = ciphertext,
            ctlist = json.dumps(ct_list),
            publicKey = str(public_key),
            phi = str(phi),receiver_mail=email)
            
            #saving file to dest
            qr_message = f"{sec_message},{ciphertext}"
            print("generated qr message is----------", qr_message)
            img = qrcode.make(qr_message, box_size=20)
            img.save(settings.MEDIA_ROOT+"/img/qrcodes/qrdemo.png")
            #creating SVG to load
            factory = qrcode.image.svg.SvgImage
            img = qrcode.make(qr_message, image_factory=factory, box_size=30)
            stream = BytesIO()
            img.save(stream)
            context["svg"] = stream.getvalue().decode()
            context['MEDIA_URL'] =  settings.MEDIA_URL
            file = open("mediafiles/img/qrcodes/qrdemo.png", 'rb')
            sent_mail_ = send_qr_mail(email,file)
            return render(request, "Admin_2.html",context=context)
        else:
            context = {"message":"Email records not found, Please share invite to user..","message_class":"alert-danger"}
            return render(request, "Admin_1.html", context=context)    
    return render(request, "Admin_1.html", context=context)


