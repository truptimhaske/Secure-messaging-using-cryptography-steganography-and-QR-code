from django.conf import settings
from django.core.mail import send_mail, EmailMessage

def send_qr_mail(receiver_email,attach):
    subject =  'QR- Mail sent'
    message = f'Hi , find attachment below to download your QR message.'
    email_from = settings.EMAIL_HOST_USER
    print(email_from)
    recipient_list = (receiver_email,)
    mail = EmailMessage(subject=subject, body=message, from_email=email_from, to=recipient_list)
    mail.attach("qr.png", attach.read())
    mail.send()
    return f"Email send to {receiver_email}"

def send_qenc_cred(receiver_email, password):
    subject =  'Invited you to see qr messages'
    message = f"""Hi , find your mail credentials below
                username - {receiver_email}
                password - {password}
                
                **Don't share your credentials with anyone
                Thanks.
                """
    email_from = settings.EMAIL_HOST_USER
    print(email_from)
    recipient_list = (receiver_email,)
    mail = EmailMessage(subject=subject, body=message, from_email=email_from, to=recipient_list)
    mail.send()
    return f"Email send for account credentials to {receiver_email}"
