from django.urls import path

from qradmin.models import SecureMessage
from .views import Admin_login, common_Logout, generate_QR

urlpatterns = [
    path("login/", Admin_login, name="adminlogin"),
    path("logout/", common_Logout, name="logout"),
    path("generateqr/", generate_QR, name="generateqr")
]
